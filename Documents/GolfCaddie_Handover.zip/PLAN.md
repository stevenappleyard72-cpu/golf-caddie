# Golf target coach — implementation plan

Status: agreed product brief; implementation has not started.
Prepared: 18 October 2026.

## Working instructions for Codex

Read this plan and `chislehurst_course/README.md` before implementation. Inspect `../mathsgrid` as a read-only reference for stack, mobile styling, local development, GitHub and Render deployment conventions. Report what can be reused before scaffolding. Keep this project in its own folder and Git repository; never copy credentials, Git history, deployment identifiers or maths game logic.

Use the existing stack where sensible. Choose the simplest implementation that meets this plan; avoid introducing frameworks and external services without a concrete need. After the initial findings, implement in small working stages. Keep this document updated with completed work, checks, decisions and remaining issues. Do not replace agreed requirements with assumptions silently. Routine implementation decisions do not need repeated approval.

This document is the handover from a design conversation. It does not imply that a benchmark model, official handicap calculator or existing working app has been supplied. Read the supplied course schema before adapting it; do not assume its field names or scoring profiles.

## Purpose and scope

A personal, single-player golf companion for a phone. Set a target handicap, record where each shot finishes, receive a simple next-shot distance target, and see how closely play meets that target. Initial use is at Chislehurst Golf Club, with a data structure that can support other courses later.

Deliver an Android-friendly progressive web app (PWA) opened by URL and addable to the home screen. No native Android build, accounts, multiplayer, payments, server database or automatic course discovery in version one. Round recording and numerical feedback must continue offline after initial loading. OpenAI commentary is optional enhancement.

## Startup

One player per round. Save the profile locally for reuse and allow edits before a new round:

- Age.
- Sex: male or female, required.
- Target Handicap Index, required. Do not ask for current handicap.
- Typical driver distance in yards, using total distance consistently.
- Longest reliable fairway shot distance in yards, using total distance consistently.
- Tee colour: red, yellow or white; default yellow.

Show Chislehurst as the prepared course. Tee selection changes course data and, when available, the sex-specific scoring profile. Show unavailable scoring combinations clearly without preventing distance tracking.

Starting a round does not capture a GPS tee position. Every hole starts at the selected tee coordinate from course data, including holes reached after finishing the preceding hole. Moved daily tee markers are outside version-one scope.

## On-course interaction

Keep the main screen readable outdoors with large buttons and few inputs. Show hole number, par where verified, strokes recorded and distance to green centre.

### Record ball position

At the ball, press **Record ball position**. Capture a fresh GPS fix with timestamp and reported accuracy. The first position recorded on a hole is where the tee shot landed. Each later position is the endpoint of the next shot, measured from the previous ball position. Never require a separate Start hole action.

Provide a small **Clear route to green? Yes / No** control, default Yes, attached to the current position. No marks a recovery situation; it is not detailed hazard modelling. Preserve the previous position's route flag so the following shot is assessed from the situation it started in. Distance alone cannot identify whether a newly reached position is blocked, so let the player correct the flag and recalculate.

Show three compact feedback lines, for example:

- Last shot: approximately 24-handicap standard.
- Next shot: finish within 40 yards of the green to meet your 12-handicap target.
- Target met on 10 of 15 assessed shots (67%).

The numbers above illustrate wording only. Generate values from the implemented model and the actual recorded position. No judgement of effort, technique or intent. Do not mention a current handicap that was never entered.

Treat GPS failures and poor fixes explicitly: allow retry or an intentional override, do not silently count duplicate taps as shots, and do not invent coordinates. A stationary or backwards shot can be real; do not reject it merely because it did not gain distance. Keep the GPS accuracy display compact. Refresh should never lose a round.

### Penalties

Provide **Record penalty**, default one penalty stroke, editable. Capture the drop position using GPS and store it as a penalty/drop event. Movement to the drop position is not a golf stroke and must not earn a shot classification or a target success. The next shot starts from the drop position.

Preserve the attempted shot separately from its penalty. If the attempted shot has not been recorded, ask a minimal question to account for it; never double count it or silently omit it. Represent an unknown endpoint as unknown, rather than claiming the drop coordinate was the attempted shot endpoint. Support a return to the previous position for stroke-and-distance penalties with minimal interaction. Include penalties in hole totals and round scoring.

### Finish hole and undo

Provide **Finish hole** with total strokes including penalties and number of putts. Pre-fill the stroke total from recorded events; allow an explicit correction, validating putts against the total. Record putts in aggregate. Do not fabricate individual putting positions or assess each putt from a total count.

Permit a picked-up hole with an explicit status, so it can contribute zero Stableford points without inventing an exact score. After finishing, automatically move to the next hole. The next Record ball position action records that hole's tee-shot endpoint from its stored tee coordinate. After hole 18, show the summary.

Allow undo of the most recent action, including a penalty or finishing a hole. Recompute derived results consistently. Preserve manual corrections and explain if a correction leaves some strokes unassessed.

## Distances and benchmark model

Use WGS84 GPS coordinates, calculate geodesic distances consistently and display yards. The remaining distance is to the mapped green centre. Do not confuse official scorecard length along the playing line with straight-line GPS distance. Version one does not track pin position or generate GPS putting targets; show next-shot targets to green centre until the player finishes the hole.

The core task is to assess the completed shot and calculate a reachable next-shot target from the ball's actual current location. A poor drive changes the next starting position; do not keep returning a prewritten target for shot number two. Use target handicap, age, sex, driver distance, reliable fairway distance, hole context and the route flag. Measured player distances take precedence over demographic assumptions. Any further age/sex adjustment must be explicit and conservative, avoiding double counting distance capability.

Implement a small deterministic, versioned, editable benchmark model locally. It may use fixed parameters or curves; its results must vary with the actual start and finish state. It must not depend on asking an LLM to invent new benchmarks every stroke.

Before coding the model, document a concrete formula or set of curves, its parameters and several worked examples in `docs/benchmark-model.md`. Include how it handles tee shots, approaches, short shots, backwards shots, recovery flags, penalties, maximum reliable distances and target handicap changes. Ensure an unreachable one-shot goal becomes a feasible lay-up target. Avoid a model that simply divides hole length by a number of strokes or treats every long shot as good. Do not infer a precise handicap from distance gained alone.

No validated empirical shot-by-handicap dataset is provided. Use a transparent provisional coaching model and label the app's shot levels and round level as estimates. Do not present generated curves as measured statistics or official handicap calculations. A brief explanation in Help is enough; do not clutter every feedback line with disclaimers or confidence ratings.

Keep the model separate from UI and AI commentary. Store its version with round assessments. The exact model is an implementation design task, not a claim already settled by this brief. Report material limitations plainly, then implement the simplest defensible version within scope.

## Progress and end-of-round feedback

- Count target successes among assessed non-putting strokes; show numerator, denominator and percentage. Unassessed strokes and drop movements must not inflate the percentage. Penalties always affect scoring and must be visible; explain their treatment in shot success reporting.
- Show an estimated overall playing handicap level from completed holes using Stableford-style net scoring, so disasters do not dominate the estimate. Do not average the shot handicap labels to obtain a round handicap.
- Specify and test how candidate handicap levels map to strokes received, points, partial-round extrapolation and the displayed estimate. Use the applicable sex/tee rating, slope, par and stroke-index profile only when supported. Verify current authoritative golf rules during implementation before claiming an official calculation. Clearly name any simplified estimate.
- Before any completed hole, show round performance as pending. If a valid scoring profile is unavailable, show distance coaching and target-shot percentage while marking the overall handicap estimate unavailable; never substitute another sex's scoring profile.
- At round end show totals, target-shot percentage, estimated overall playing level when available, and a compact breakdown of assessed shots by handicap band. Use broad bands rather than implying exact per-shot precision. No confidence score is needed.

## Course data

The supplied directory is `chislehurst_course/` extracted from `Chislehurst_Course_Data.zip`. Keep an original copy in the project and use a separate adapter for the runtime format if needed.

Read these first:

- `README.md` — provenance, scoring limitations and coordinate quality.
- `chislehurst-course.json` — course schema, 18 holes, tee sets, ratings and quality flags.
- `chislehurst-coordinates.csv` and the supplied map images — visual checking aids.

Keep the app course-independent: load one course object by ID instead of embedding Chislehurst assumptions throughout UI or scoring code. No external course API is needed initially. Coordinates must be replaceable through data edits, with no algorithm rewrite.

Important supplied-data limitations:

- Green centres are centroids of matched OpenStreetMap green polygons, not surveyed pin positions.
- Mapped reference tee points have no verified colour in the source.
- Red/yellow/white tee coordinates are inferred and explicitly provisional. Some overlap. Keep quality flags, attribution and correction capability; do not relabel them as verified.
- The mapped geometry dates from 2020–2021; downloading in 2026 does not make it a 2026 survey.
- Men's white/yellow and women's red have the supplied corresponding per-hole scorecard arrays. Women's yellow rating is available, but its female per-hole par/stroke-index profile remains unconfirmed. Do not use the men's yellow array for women.
- Male red rating is secondary-source-only; female white rating is unconfirmed. Disable unsupported official-style scoring combinations until verified. Distance coaching can still work.
- Hole-one published lengths conflict between the club overview and individual hole page; the dataset consistently uses the overview and flags the difference.
- Preserve OpenStreetMap attribution, ODbL licence information and source metadata as described in the README.

## Client, server and OpenAI responsibilities

### Phone/client — authoritative round state

Own profile, course data, GPS capture, event history, undo, round storage, scoring, benchmark calculations and all essential feedback. Persist every accepted action locally, preferably in IndexedDB. Cache app shell and course data using a service worker. Provide resume after closing the browser and JSON export/import for backup. Keep data formats versioned.

Home-screen installation, GPS and service workers must work over HTTPS. Provide clear location-permission handling. Do not rely on background GPS tracking; capture positions while the user is interacting with the app.

### Render server — small stateless API

Keep the OpenAI key in server environment variables only. Validate request size and schema; apply appropriate access protection, rate limits, timeouts and output validation. Do not use a hardcoded public browser secret as authentication. For this personal prototype, a simple server-verified access code with a short-lived session is acceptable; document the setup. Avoid storing round histories, player profiles or raw GPS traces in server logs. No server database is required.

Reuse mathsgrid deployment conventions where suitable. Prefer a static frontend plus a small API service if compatible with the existing stack; a single service is acceptable if it is simpler and preserves offline operation. A sleeping/free backend must not prevent play. Document deploy configuration and environment variables; leave the hosting plan choice to the user.

### OpenAI — optional concise commentary

Use the current supported OpenAI Responses API with a structured output schema, verified against official documentation during implementation. The server sends a compact snapshot containing the profile information needed, hole context, validated last-shot assessment, next-shot target and progress totals. OpenAI expresses those results in tidy text; it does not own state, look up course coordinates or recalculate scores.

Use independent snapshot requests; no long-lived AI conversation is required. Include `roundId` and a monotonically increasing `revision`. Return those with the response and ignore stale responses after new shots, undo or reset. Request fields such as `lastShotText`, `nextShotText`, and `progressText`. Do not let model output overwrite numerical state or invent benchmarks. Use local text templates immediately and whenever AI is slow, unavailable or invalid. Avoid replaying a backlog of commentary requests after reconnection.

Use `store: false` where supported to avoid storing API response state; do not claim that this guarantees zero data retention. No browser OpenAI calls and no embedded API keys. Coding with the user's ChatGPT subscription is separate from runtime API billing.

## Test at home before the first round

On-course testing is difficult to iterate. A development simulation mode is a first-stage requirement, using the same recording and assessment paths as real GPS. Allow simulated positions via a simple local course view or coordinate controls and repeatable scripted rounds. Do not require a paid map API. Keep simulation clearly labelled and isolated from real round data.

Meaningful checks must include:

- A typical drive and approach, a short or backwards drive, an overshoot and a recovery position.
- Target handicap and profile changes producing sensible, reachable next targets.
- Penalty/drop versus attempted shot accounting, stroke-and-distance, undo and manual totals.
- Finishing a hole, automatic advance, next tee-shot endpoint and all 18 holes.
- GPS denied, unavailable and poor accuracy; duplicate taps; position retry.
- Offline startup after caching, offline full round, reload/resume and export/import.
- Delayed, failed, malformed and stale AI responses, including revision changes after undo.
- Correct supported scoring profiles; unavailable combinations must not silently score.
- Fixed worked benchmark/scoring examples with expected results independent of implementation.

Use unit tests for numerical/state logic and a small set of integration/browser checks for critical round flows. Test Android Chrome/home-screen behaviour on the real phone before the course visit. The first practice round should mainly validate coordinates and usability, not uncover basic accounting or recovery failures.

## Delivery stages

- [ ] 1. Inspect ../mathsgrid; record reusable conventions and recommended structure here.
- [ ] 2. Scaffold the separate project, mobile shell, PWA support, local persistence, backend health endpoint and documented local/Render commands. Supply .env.example with placeholders only.
- [ ] 3. Load/adapt the supplied course data, profile startup and simulation mode.
- [ ] 4. Implement event recording, penalties, undo, finish/advance, resume and export/import with numerical/state checks.
- [ ] 5. Document and implement the provisional benchmark model and supported Stableford-based round estimate, with worked examples and tests.
- [ ] 6. Add compact feedback, progress and round summary; verify an entire simulated offline round.
- [ ] 7. Add optional server-mediated OpenAI commentary with safe fallback, access protection and stale-response handling.
- [ ] 8. Complete home/phone checks and document deployment and a short first-round checklist.

Commit working milestones locally. Do not deploy, push or modify remote repositories merely because a configuration exists; follow the user's instructions for publishing. Keep the user informed of concrete results and any decision that changes product scope.

## Implementation notes and checks

Update this section as work proceeds. Record actual commands and outcomes, not claims that checks passed without running them.

- Existing-project inspection: pending.
- Stack and hosting structure: pending inspection.
- Benchmark formula and parameters: pending implementation design.
- Supported scoring profiles: use dataset flags; confirm in adapter checks.
- Tests and phone checks: not run; app not implemented.
